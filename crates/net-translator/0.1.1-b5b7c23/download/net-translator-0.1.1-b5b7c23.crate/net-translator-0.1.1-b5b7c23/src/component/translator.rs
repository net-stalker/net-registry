use std::rc::Rc;
use threadpool::ThreadPool;
use net_core::layer::NetComponent;

use net_transport::zmq::builders::dealer::ConnectorZmqDealerBuilder;
use net_transport::polling::zmq::ZmqPoller;
use net_transport::zmq::contexts::dealer::DealerContext;

use crate::command::decoder::DecoderCommand;
use crate::config::Config;

pub struct Translator {
    pool: ThreadPool,
    config: Config,
}

impl Translator {
    pub fn new(pool: ThreadPool, config: Config) -> Self {
        Self { pool, config }
    }
}

impl NetComponent for Translator {
    fn run(self) {
        log::info!("Run component");
        let dealer_context = DealerContext::default();
        self.pool.execute(move || {
            let hub_connector = ConnectorZmqDealerBuilder::new(&dealer_context)
                .with_endpoint(self.config.hub_connector.addr)
                .with_handler(Rc::new(DecoderCommand::default()))
                .build()
                .connect()
                .into_inner();

            ZmqPoller::new()
                .add(hub_connector)
                .poll(-1);
        });
    }
}
