use std::fmt::{Debug, Formatter};

use serde::{Deserialize, Serialize};
use toml::to_string;
use net_config::NetConfig;

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct AgentEndpoint {
    pub(crate) addr: String,
}

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct TranslatorEndpoint {
    pub(crate) addr: String,
}

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct InserterEndpoint {
    pub(crate) addr: String,
}

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq, NetConfig)]
pub struct Config {
    pub(crate) agent_endpoint: AgentEndpoint,
    pub(crate) translator_endpoint: TranslatorEndpoint,
    pub(crate) inserter_endpoint: InserterEndpoint,
}

#[cfg(test)]
mod tests {
    use std::env;
    
    use super::*;

    #[test]
    fn expected_load_config() {
        let config = Config::builder()
            .with_config_dir(".config".to_string())
            .build();

        let expected_config = Config {
            agent_endpoint: AgentEndpoint { addr: "tcp://0.0.0.0:5555".to_string() },
            translator_endpoint: TranslatorEndpoint { addr: "tcp://0.0.0.0:5556".to_string() },
            inserter_endpoint: InserterEndpoint { addr: "tcp://0.0.0.0:5557".to_string() }, 
        };

        assert_eq!(config.unwrap(), expected_config);

        env::set_var("NET_AGENT_ENDPOINT.ADDR", "tcp://localhost:5555");
        env::set_var("NET_TRANSLATOR_ENDPOINT.ADDR", "tcp://localhost:5556");
        env::set_var("NET_INSERTER_ENDPOINT.ADDR", "tcp://localhost:5557");
        
        let config = Config::builder()
            .with_config_dir(".config".to_string())
            .build();

        let expected_config = Config {
            agent_endpoint: AgentEndpoint {
                addr: "tcp://localhost:5555".to_string(),
            },
            translator_endpoint: TranslatorEndpoint { addr: "tcp://localhost:5556".to_string() },
            inserter_endpoint: InserterEndpoint { addr: "tcp://localhost:5557".to_string() },
        };

        assert_eq!(config.unwrap(), expected_config);
    }
}
