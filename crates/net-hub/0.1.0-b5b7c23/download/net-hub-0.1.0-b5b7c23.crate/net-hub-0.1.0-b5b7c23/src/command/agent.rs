use std::rc::Rc;
use log::debug;
use net_transport::sockets::{Handler, Receiver, Sender};

pub struct AgentHandler<S: ?Sized> {
    pub translator: Rc<S>,
}

impl<S: Sender + ?Sized> Handler for AgentHandler<S> {
    fn handle(&self, receiver: &dyn Receiver, _sender: &dyn Sender) {
        let data = receiver.recv();
        debug!("received data from net-agent");

        self.translator.send(data.as_slice());
    }
}