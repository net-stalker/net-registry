pub trait NetComponent {
    fn run(self);
}